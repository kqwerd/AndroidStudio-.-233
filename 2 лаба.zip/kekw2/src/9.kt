fun main() {
    println("Введите число m:")
    val m=readln()?.toInt() ?:0
    println("Введите число n:")
    val n=readln()?.toInt() ?:0
    val result = when { n == 0 -> "Деление  на ноль невозможно"
        m % n ==0-> "Частное от деления:${m/n}"
        else ->"$m на $n нацело не делится"
    }
println(result)
}