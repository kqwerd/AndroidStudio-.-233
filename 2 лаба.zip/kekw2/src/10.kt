fun main() {
    val a = readln()!!.toInt()
    val b = readln()!!.toInt()
    println(when{
        a == 0 -> "Ноль не может быть делителем"
        b % a == 0 -> "$a является делителем числа $b"
        else -> "$a не является делителем числа $b"
    })
}