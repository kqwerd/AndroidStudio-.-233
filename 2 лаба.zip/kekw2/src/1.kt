fun main() {
    println("Введитие 3 числа")
val numbers=List(3) { readLine()!!.toDouble()}
val maxnumber =numbers.maxOrNull() ?:Double.NEGATIVE_INFINITY
    println("Максимальное число: $maxnumber")

}