fun main() {
    println("Введите натуральное число:")
    val num = readln()?.toInt() ?: 0
    println("a) ${
        if (num % 2 == 0) "четное" else "нечетное"
    }")
    println("b) ${
        if (num % 10 == 7) "оканчивается на 7" else "не оканчивается на 7"
    }")
}