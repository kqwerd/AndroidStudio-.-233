fun main(){
    val numbers = List(3)
    {readln().toInt()}
    if (numbers.distinct().size != 3){
        println("Ошибка")
    } else{
        println("Среднее число: ${numbers.sorted()[1]}")
    }
}