fun main() {
    val n = readln()!!.toInt()
    if (n in 10..99){
        val (f, s) = n/10 to n%10
        println("a) ${when {
            f > s -> "Первая больше"
            f < s -> "Вторая больше"
            else -> "Равны"
        }}\nb) ${if (f==s) "Одинаковые" else "Разные"}")
    } else println("Число должно быть двузначным")
}