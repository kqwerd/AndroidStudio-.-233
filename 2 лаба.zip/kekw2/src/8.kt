fun main() {
    println("Введите расстояние в километрах: ")
    val km = readln()!!.toDouble()
    println("Введите расстояние в футах: ")
    val ft = readln()!!.toDouble()

    val mFromKm = km * 1000
    val mFromFt = ft * 0.305

    when{
        mFromKm < mFromFt -> println("Расстояние в километрах ($km км) меньше")
        mFromKm > mFromFt -> println("Расстояние в футах ($km км) меньше")
        else -> println("Расстояния равны")
    }
}