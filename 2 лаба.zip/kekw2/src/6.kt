fun main() {
    println("Введите год: ")
    val year = readln()!!.toInt()
    val isLeap = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)
    val days = if (isLeap) 366 else 365
    println(if (isLeap)
    "Високосный год" else "Не високосный год"
    )
    println("Количество дней: $days")
}