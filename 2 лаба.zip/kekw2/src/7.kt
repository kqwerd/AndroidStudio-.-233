fun main() {
    println("Введите первое число :")
    val num1 = readln()?.toDouble() ?: 0.0
    println("Введите второе число :")
    val num2 = readln()?.toDouble() ?: 0.0
    println("Большее число: ${maxOf (num1, num2)}")
    println("Меньшее число: ${minOf (num1, num2)}")
}