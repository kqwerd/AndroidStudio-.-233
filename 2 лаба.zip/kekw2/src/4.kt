fun main() {
    println("Введите большее число: ")
    val first= readln()!!.toInt()
    println("Введите меньшее число: ")
    val second= readln()!!.toInt()

    val remainder = first % second
    if(remainder == 0) {
        println("$first кратно $second")
    } else{
        println("$first не кратно $second")
        println("остаток $remainder")
    }
}
