fun main() {
    val a = readln()!!.toDouble()
    val b = readln()!!.toDouble()
    val c = readln()!!.toDouble()


    if(a<b+c && b<a+c && c<a+b) {
        println("Треугольник существует")
    } else {
        println("Треугольник не существует")
    }
}