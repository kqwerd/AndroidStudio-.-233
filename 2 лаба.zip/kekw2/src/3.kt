fun main() {
    val a = readln().toInt()
    val b = readln().toInt()

    when {
        a % 2 == b % 2 ->
            println("Числа должны иметь разную четность")
        a %2 != 0 -> println(a)
        else -> println(b)
    }
}